from __future__ import annotations

APP_VERSION = "0.1.1"
