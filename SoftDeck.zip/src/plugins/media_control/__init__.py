from __future__ import annotations

from .plugin import MediaControlPlugin

Plugin = MediaControlPlugin
